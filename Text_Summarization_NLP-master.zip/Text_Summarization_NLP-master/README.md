Text summarization using Natural Language Processing
